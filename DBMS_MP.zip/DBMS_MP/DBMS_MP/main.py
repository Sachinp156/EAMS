from flask import Flask,render_template,request,session,redirect,url_for,flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash,check_password_hash
from flask_login import login_user,logout_user,login_manager,LoginManager
from flask_login import login_required,current_user
import json

app = Flask(__name__)
app.secret_key='s3cr3t'

#DB Connection
local_server = True
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+mysqlconnector://root:@localhost/eams"
db = SQLAlchemy(app)

#User access
login_manager = LoginManager(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return alogin.query.get(int(user_id))


#Table Classes
class alogin(UserMixin,db.Model):
    id = db.Column(db.Integer,primary_key=True)
    username = db.Column(db.String(50))
    email = db.Column(db.String(50),unique=True)
    password = db.Column(db.String(100))


class Attendance(db.Model):
    aemp_id = db.Column( db.ForeignKey('employee.emp_id'), nullable=False)
    aemp_id=db.Column(db.Integer, primary_key = True)
    working_days= db.Column(db.Integer)
    leave_days = db.Column(db.Integer)
    total_days = db.Column(db.Integer)

class Employee(db.Model):
    emp_id = db.Column(db.Integer, primary_key = True)
    fname = db.Column(db.String(20))
    lname = db.Column(db.String(20))
    age = db.Column(db.Integer)
    gender = db.Column(db.String(20))
    dept_id = db.Column(db.Integer, db.ForeignKey('department.dept_id'), nullable=False)
    salary = db.Column(db.String)
    address = db.Column(db.String(20))

class Department(db.Model):
    dept_id = db.Column(db.Integer, primary_key = True)
    dept_name = db.Column(db.String(20))
    no_of_emp = db.Column(db.Integer)

class Trigger_emp(db.Model):
    tgid = db.Column(db.Integer, primary_key = True)
    emp_id = db.Column(db.Integer)
    lname = db.Column(db.String(50))
    salary = db.Column(db.Integer)
    action = db.Column(db.String(50))
    timestamp = db.Column(db.String(50))

@app.route("/")
def index():
    return render_template('index.html')

@app.route('/signup',methods=['POST','GET'])
def signup():
    if request.method == "POST":
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        user = alogin.query.filter_by(email = email).first()
        if user:
            flash("Email already exists","warning")
            return render_template('/signup.html')
        encpassword = generate_password_hash(password)

        new_user = db.engine.execute(f"INSERT INTO `alogin` (`username`,`email`,`password`) VALUES ('{username}','{email}','{encpassword}')")

        flash("Account created, please login","success")
        return render_template('login.html')
    return render_template('/signup.html')

@app.route('/login',methods=['POST','GET'])
def login():
    if request.method == "POST":
        email=request.form.get('email')
        password=request.form.get('password')
        user=alogin.query.filter_by(email=email).first()

        if user and check_password_hash(user.password,password):
            login_user(user)
            flash("Logged in succesfully","primary")
            return redirect(url_for('index'))
        else:
            flash("Invalid Credentials","danger")
            return render_template('login.html')    

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("Logout SuccessFul","warning")
    return redirect(url_for('index'))

@app.route('/employee')
@login_required
def employees(): 
    query = db.engine.execute(f"SELECT * FROM `employee`")
    return render_template('employee.html', query = query)

@app.route('/Attendance')
@login_required
def attendance(): 
    query = db.engine.execute(f"SELECT * FROM `attendance`")
    return render_template('attendance.html', query = query)

@app.route('/department')
@login_required
def department(): 
    query = db.engine.execute(f"SELECT * FROM `department`")
    return render_template('department.html', query = query)

@app.route('/add_employee', methods = ['POST','GET'])
@login_required
def add_employee(): 
    if request.method=="POST":
        eid = request.form.get('eid')
        fname = request.form.get('fname')
        lname = request.form.get('lname')
        did = request.form.get('did')
        age = request.form.get('age')
        gender = request.form.get('gender')
        salary = request.form.get('salary')
        address = request.form.get('address')
        query = db.engine.execute(f"INSERT INTO `employee` (`emp_id`,`fname`,`lname`,`dept_id`,`age`,`gender`,`salary`,`address`) VALUES ('{eid}','{fname}','{lname}','{did}','{age}','{gender}','{salary}','{address}')")
        flash("New employee added","primary")
        return redirect('employee')

    return render_template('add_employee.html')

@app.route("/delete_employee/<string:emp_id>",methods=['POST','GET'])
@login_required
def delete_employee(emp_id):
    db.engine.execute(f"DELETE FROM `employee` WHERE `employee`.`emp_id`={emp_id}")
    flash("Employee Deleted Successfully","danger")
    return redirect('/employee')

@app.route("/edit_employee/<string:emp_id>",methods=['POST','GET'])
@login_required
def edit_employee(emp_id):
    posts = Employee.query.filter_by(emp_id=emp_id).first()
    # dept = db.engine.execute("SELECT * FROM `department`")
    if request.method == "POST":
        # emp_id = request.form.get('emp_id')
        fname = request.form.get('fname')
        lname = request.form.get('lname')
        dept_id = request.form.get('dept_id')
        age = request.form.get('age')
        gender = request.form.get('gender')
        salary = request.form.get('salary')
        address = request.form.get('address')

        db.engine.execute(f"UPDATE `employee` SET `fname` = '{fname}',`lname` = '{lname}', `age` = '{age}', `dept_id` = '{dept_id}', `gender` = '{gender}',`salary` = '{salary}', `address` = '{address}' WHERE `employee`.`emp_id` = {emp_id}")
        flash("Employee Updated","success")
        return redirect('/employee')
    
    return render_template('edit_employee.html',posts = posts)

@app.route('/add_dept', methods = ['POST','GET'])
@login_required
def add_dept():
    teams = db.engine.execute("SELECT * FROM `department`") 
    if request.method == "POST":
        dept_id = request.form.get('dept_id')
        dept_name = request.form.get('dept_name')
        no_of_emp = request.form.get('no_of_emp')
        query = db.engine.execute(f"INSERT INTO `department` (`dept_id`,`dept_name`,`no_of_emp`) VALUES ('{dept_id}','{dept_name}','{no_of_emp}')")
        flash("New dept added","primary")
        return redirect('department')

    return render_template('add_dept.html')

@app.route("/delete_dept/<string:dept_id>",methods=['POST','GET'])
@login_required
def delete_dept(dept_id):
    db.engine.execute(f"DELETE FROM `department` WHERE `department`.`dept_id`={dept_id}")
    flash("Department Deleted Successfully","danger")
    return redirect('/department')

@app.route("/edit_dept/<string:dept_id>",methods=['POST','GET'])
@login_required
def edit_dept(dept_id):
    posts = Department.query.filter_by(dept_id = dept_id).first()
    if request.method == "POST":
        dept_id= request.form.get('dept_id')
        dept_name = request.form.get('dept_name')
        no_of_emp = request.form.get('no_of_emp')
        query=db.engine.execute(f"UPDATE `department` SET `dept_name` = '{dept_name}', `no_of_emp` = '{no_of_emp}' WHERE `department`.`dept_id` = '{dept_id}'")
        flash("Department Updated","success")
        return redirect('/department')
    
    return render_template('edit_dept.html', posts = posts)

@app.route('/add_attendance', methods = ['POST','GET'])
@login_required
def add_attendance():
    teams = db.engine.execute("SELECT * FROM `attendance`") 
    if request.method == "POST":
        aemp_id = request.form.get('aemp_id')
        working_days = request.form.get('working_days')
        leave_days = request.form.get('leave_days')
        total_days = request.form.get('total_days')
        query = db.engine.execute(f"INSERT INTO `attendance` (`aemp_id`,`working_days`,`leave_days`,`total_days`) VALUES ('{aemp_id}','{working_days}','{leave_days}','{total_days}')")
        flash("New Attendance Record added","primary")
        return redirect('/Attendance')

    return render_template('add_attendance.html')

@app.route("/delete_attendance/<string:aemp_id>",methods=['POST','GET'])
@login_required
def delete_attendance(aemp_id):
    db.engine.execute(f"DELETE FROM `attendance` WHERE `attendance`.`aemp_id`={aemp_id}")
    flash("Attendance Record  Deleted Successfully","danger")
    return redirect('/Attendance')

@app.route("/edit_attendance/<string:aemp_id>",methods=['POST','GET'])
@login_required
def edit_attendance(aemp_id):
    posts = Attendance.query.filter_by(aemp_id = aemp_id).first()
    if request.method == "POST":
        working_days = request.form.get('working_days')
        leave_days = request.form.get('leave_days')
        total_days = request.form.get('total_days')
        query=db.engine.execute(f"UPDATE `attendance` SET `working_days` = '{working_days}', `leave_days` = '{leave_days}' , `total_days` = '{total_days}'WHERE `attendance`.`aemp_id` = '{aemp_id}'")
        flash("Attendance Record  Updated","success")
        return redirect('/Attendance')
    
    return render_template('/edit_attendance.html', posts = posts)

@app.route('/emprecord')
@login_required
def emprecord(): 
    query = db.engine.execute(f"SELECT * FROM `trigger_emp`")
    return render_template('emprecord.html', query = query)

app.run(debug = True)