from flask import Flask,render_template,request,session,redirect,url_for,flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash,check_password_hash
from flask_login import login_user,logout_user,login_manager,LoginManager
from flask_login import login_required,current_user
from flask_mail import Mail
import json

app = Flask(__name__)
app.secret_key='s3cr3t'

#DB Connection
local_server = True
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+mysqlconnector://root:@localhost/kabaddi"
db = SQLAlchemy(app)

#User access
login_manager = LoginManager(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


#Table Classes
class User(UserMixin,db.Model):
    id = db.Column(db.Integer,primary_key=True)
    username = db.Column(db.String(50))
    email = db.Column(db.String(50),unique=True)
    password = db.Column(db.String(100))


class Teams(db.Model):
    tid = db.Column(db.Integer, primary_key = True)
    Tname = db.Column(db.String(20))
    HCity = db.Column(db.String(20))
    Total_matches = db.Column(db.Integer)
    Total_wins = db.Column(db.Integer)

class Players(db.Model):
    pid = db.Column(db.Integer, primary_key = True)
    Name = db.Column(db.String(20))
    Age = db.Column(db.Integer)
    tid = db.Column(db.Integer, db.ForeignKey('teams.tid'), nullable=False)
    Type = db.Column(db.String)

class Matches(db.Model):
    mno = db.Column(db.Integer, primary_key = True)
    Venue = db.Column(db.String(20))
    Date = db.Column(db.String())
    Time = db.Column(db.String())
    Team_1 = db.Column(db.Integer)
    Team_2 = db.Column(db.Integer)

@app.route("/")
def index():
    return render_template('index.html')

@app.route('/signup',methods=['POST','GET'])
def signup():
    if request.method == "POST":
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email = email).first()
        if user:
            flash("Email already exists","warning")
            return render_template('/signup.html')
        encpassword = generate_password_hash(password)

        new_user = db.engine.execute(f"INSERT INTO `user` (`username`,`email`,`password`) VALUES ('{username}','{email}','{encpassword}')")

        flash("Account created, please login","success")
        return render_template('login.html')
    return render_template('/signup.html')

@app.route('/login',methods=['POST','GET'])
def login():
    if request.method == "POST":
        email=request.form.get('email')
        password=request.form.get('password')
        user=User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password,password):
            login_user(user)
            flash("Logged in succesfully","primary")
            return redirect(url_for('index'))
        else:
            flash("Invalid Credentials","danger")
            return render_template('login.html')    

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("Logout SuccessFul","warning")
    return redirect(url_for('index'))

@app.route('/players')
@login_required
def players(): 
    query = db.engine.execute(f"SELECT * FROM `players`")
    return render_template('players.html', query = query)

@app.route('/teams')
@login_required
def teams(): 
    query = db.engine.execute(f"SELECT * FROM `teams`")
    return render_template('teams.html', query = query)

@app.route('/add_player', methods = ['POST','GET'])
@login_required
def add_player():
    teams = db.engine.execute("SELECT * FROM `teams`") 
    if request.method=="POST":
        pid = request.form.get('pid')
        Name = request.form.get('name')
        Age = request.form.get('age')
        tid = request.form.get('tid')
        Type = request.form.get('type')
        query = db.engine.execute(f"INSERT INTO `players` (`pid`,`Name`,`Age`,`tid`,`Type`) VALUES ('{pid}','{Name}','{Age}','{tid}','{Type}')")
        flash("New player added","primary")
        return redirect('players')

    return render_template('add_player.html', teams = teams)

@app.route("/delete/<string:pid>",methods=['POST','GET'])
@login_required
def delete_player(pid):
    db.engine.execute(f"DELETE FROM `players` WHERE `players`.`pid`={pid}")
    flash("Player Deleted Successfully","danger")
    return redirect('/players')

@app.route("/edit/<string:pid>",methods=['POST','GET'])
@login_required
def edit_player(pid):
    posts = Players.query.filter_by(pid=pid).first()
    teams = db.engine.execute("SELECT * FROM `teams`")
    p_team = db.session.query(Players, Teams.Tname).filter(Teams.tid == Players.tid).filter(Players.pid == pid)
    p_type = db.session.query(Players.Type, Teams).filter(Teams.tid == Players.tid).filter(Players.pid == pid)
    if request.method == "POST":
        pid = request.form.get('pid')
        Name = request.form.get('name')
        Age = request.form.get('age')
        tid = request.form.get('tid')
        Type = request.form.get('type')
        db.engine.execute(f"UPDATE `players` SET `Name` = '{Name}', `Age` = '{Age}', `tid` = '{tid}', `Type` = '{Type}' WHERE `players`.`pid` = {pid}")
        flash("Player Updated","success")
        return redirect('/players')
    
    return render_template('edit_player.html', posts = posts, teams = teams, p_team = p_team, p_type = p_type)

@app.route('/add_team', methods = ['POST','GET'])
@login_required
def add_team():
    teams = db.engine.execute("SELECT * FROM `teams`") 
    if request.method == "POST":
        tid = request.form.get('tid')
        TName = request.form.get('Tname')
        HCity = request.form.get('HCity')
        Total_matches = request.form.get('Total_matches')
        Total_wins = request.form.get('Total_wins')
        query = db.engine.execute(f"INSERT INTO `teams` (`tid`,`TName`,`HCity`,`Total_matches`,`Total_wins`) VALUES ('{tid}','{TName}','{HCity}','{Total_matches}','{Total_wins}')")
        flash("New team added","primary")
        return redirect('teams')

    return render_template('add_team.html', teams = teams)

@app.route("/delete_team/<string:tid>",methods=['POST','GET'])
@login_required
def delete_team(tid):
    db.engine.execute(f"DELETE FROM `teams` WHERE `teams`.`tid`={tid}")
    flash("Team Deleted Successfully","danger")
    return redirect('/teams')

@app.route("/edit_team/<string:tid>",methods=['POST','GET'])
@login_required
def edit_team(tid):
    posts = Teams.query.filter_by(tid = tid).first()
    if request.method == "POST":
        tid = request.form.get('tid')
        TName = request.form.get('Tname')
        HCity = request.form.get('HCity')
        Total_matches = request.form.get('Total_matches')
        Total_wins = request.form.get('Total_wins')
        db.engine.execute(f"UPDATE `teams` SET `Tname` = '{TName}', `HCity` = '{HCity}', `Total_matches` = '{Total_matches}', `Total_wins` = '{Total_wins}' WHERE `teams`.`tid` = {tid}")
        flash("Team Updated","success")
        return redirect('/teams')
    
    return render_template('edit_team.html', posts = posts)


app.run(debug = True)